import os
import pytest
from diag_tool.cli import inspect_system

def test_diagnostic_success():
    result = inspect_system()
    assert result["code"] == 0
    assert "python_version" in result["data"]
    assert "disk_space" in result["data"]

def test_malformed_config_path():
    result = inspect_system("/non/existent/path/config.json")
    assert result["code"] == 2
    assert "error" in result

def test_missing_dependency(monkeypatch):
    monkeypatch.setenv("SIMULATE_MISSING_DEP", "1")
    result = inspect_system()
    assert result["code"] == 3
    assert "error" in result
