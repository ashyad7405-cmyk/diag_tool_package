import argparse
import sys
import os
import shutil
import json
import platform

def inspect_system(config_path=None):
    if config_path and not os.path.exists(config_path):
        return {"error": "Malformed configuration path", "code": 2}
    
    # Check for a hypothetical critical dependency for error testing
    # If a specific env var trigger is set, we simulate missing dependency
    if os.environ.get("SIMULATE_MISSING_DEP") == "1":
        return {"error": "Critical dependency missing", "code": 3}

    # Python info
    py_ver = platform.python_version()

    # Disk space
    total, used, free = shutil.disk_usage("/")
    disk_info = {
        "total_gb": round(total / (1024**3), 2),
        "used_gb": round(used / (1024**3), 2),
        "free_gb": round(free / (1024**3), 2),
        "percent_used": round((used / total) * 100, 2)
    }

    # Env vars (sample or all)
    env_vars = dict(os.environ)

    # Dev tools
    tools = ["git", "docker", "pip", "poetry"]
    dev_tools = {tool: shutil.which(tool) is not None for tool in tools}

    return {
        "code": 0,
        "data": {
            "python_version": py_ver,
            "disk_space": disk_info,
            "environment_variables_count": len(env_vars),
            "developer_tools": dev_tools
        }
    }

def main():
    parser = argparse.ArgumentParser(description="System Diagnostic CLI Tool")
    parser.add_argument("--json", action="store_true", help="Output results in JSON format")
    parser.add_argument("--config", type=str, help="Path to configuration file")
    args = parser.parse_args()

    result = inspect_system(args.config)
    exit_code = result["code"]

    if exit_code != 0:
        if args.json:
            print(json.dumps({"error": result["error"]}, indent=2))
        else:
            print(f"Error: {result['error']}", file=sys.stderr)
        sys.exit(exit_code)

    data = result["data"]
    if args.json:
        print(json.dumps(data, indent=2))
    else:
        print("=== SYSTEM DIAGNOSTICS REPORT ===")
        print(f"Python Version: {data['python_version']}")
        print(f"Disk Space: {data['disk_space']['free_gb']} GB free out of {data['disk_space']['total_gb']} GB ({data['disk_space']['percent_used']}% used)")
        print(f"Environment Variables Count: {data['environment_variables_count']}")
        print("Developer Tools Available:")
        for tool, available in data['developer_tools'].items():
            status = "✔ Available" if available else "✘ Not Found"
            print(f"  - {tool}: {status}")
    
    sys.exit(0)

if __name__ == '__main__':
    main()
